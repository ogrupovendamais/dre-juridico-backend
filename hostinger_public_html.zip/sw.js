// PWA 3.0: cache restrito a recursos publicos estaticos; nunca cachear /api, sessao ou dados privados.
const CACHE = 'dre-juridico-static-v140';
const ASSETS = ['./index.html', './app.js', './manifest.webmanifest', './icon.svg', './favicon.ico', './favicon.png', './favicon-32x32.png'];

self.addEventListener('install', event => {
    event.waitUntil((async () => {
        const cache = await caches.open(CACHE);
        await cache.addAll(ASSETS);
        await self.skipWaiting();
    })());
});

self.addEventListener('activate', event => {
    event.waitUntil((async () => {
        for (const key of await caches.keys()) {
            if (key.startsWith('dre-juridico-static-') && key !== CACHE) {
                await caches.delete(key);
            }
        }
        await self.clients.claim();
    })());
});

self.addEventListener('fetch', event => {
    const req = event.request;
    const url = new URL(req.url);
    if (req.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;

    if (req.mode === 'navigate') {
        event.respondWith(
            fetch(req).catch(() => caches.match('./index.html'))
        );
        return;
    }

    const allowed = ASSETS.map(asset => new URL(asset, self.registration.scope).pathname);
    if (!allowed.includes(url.pathname)) return;

    event.respondWith(
        fetch(req)
            .then(response => {
                if (response.ok) {
                    const copy = response.clone();
                    caches.open(CACHE).then(cache => cache.put(req, copy));
                }
                return response;
            })
            .catch(() => caches.match(req, { ignoreSearch: true }))
    );
});
